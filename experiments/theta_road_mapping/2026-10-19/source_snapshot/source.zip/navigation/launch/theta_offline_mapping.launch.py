"""THETA オフライン路面マッピング用ランチ（sirius_navigation）。

記録済みrosbagを再生しながら:
  theta_bev_node         : /theta/dual_fisheye/image_raw/compressed -> /theta/bev/image_raw
  theta_ground_cloud_node: /theta/bev/image_raw -> /theta/ground_cloud (z=0の地面点群)
  theta_indexed_map_node : /theta/ground_cloud -> /theta/colored_map_grid (代表色indexed地図)
  theta_sam3_perspective_node (sam3:=true): 透視投影SAM3 -> /theta/bev_semantic
  rtabmap                : /theta/ground_cloud -> /rtabmap/grid_map, /cloud_map

SAM3・ステレオ・深度は使用しない。姿勢TFはbag内の補正済みTFを使う。
校正は package share の config/theta_calibration.yaml を既定で使用。

デバッグ可視化: publish_debug:=true で透視ビュー/マスク/オーバーレイ/意味色点群を配信。
rviz_config:=<path> でRViz設定を差し替え（theta_debug.rviz で検出〜地図を同時表示）。
"""
import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    share = get_package_share_directory('sirius_navigation')
    use_sim_time = LaunchConfiguration('use_sim_time')
    rviz = LaunchConfiguration('rviz')
    rviz_config = LaunchConfiguration('rviz_config')
    sam3 = LaunchConfiguration('sam3')
    publish_raw = LaunchConfiguration('publish_raw')
    publish_debug = LaunchConfiguration('publish_debug')
    calibration = LaunchConfiguration('calibration')
    min_radius = LaunchConfiguration('min_radius')
    max_radius = LaunchConfiguration('max_radius')
    grid_range_max = LaunchConfiguration('grid_range_max')
    lidar_topic = LaunchConfiguration('lidar_topic')
    lidar_gate = LaunchConfiguration('lidar_gate')
    lidar_strict = LaunchConfiguration('lidar_strict_visibility')
    lidar_padding = LaunchConfiguration('lidar_obstacle_padding_m')
    rear_weight = LaunchConfiguration('rear_observation_weight')
    min_relative_weight = LaunchConfiguration('min_relative_observation_weight')
    quality_weight_enable = LaunchConfiguration('quality_weight_enable')
    quality_power = LaunchConfiguration('quality_power')
    quality_weight_floor = LaunchConfiguration('quality_weight_floor')
    use_observation_weight = LaunchConfiguration('use_observation_weight')
    texture_decay = LaunchConfiguration('texture_decay')
    class_weight_switch = LaunchConfiguration('class_weight_switch')
    semantic_min_weight = LaunchConfiguration('semantic_min_weight')
    semantic_debug_topic = PythonExpression(
        ["'/theta/ground_cloud_semantic' if '", publish_debug, "' == 'true' else ''"])

    declare_use_sim_time = DeclareLaunchArgument(
        'use_sim_time', default_value='true',
        description='Use simulation (rosbag) clock')
    declare_rviz = DeclareLaunchArgument(
        'rviz', default_value='false',
        description='Launch RViz2 to preview the map during replay')
    declare_rviz_config = DeclareLaunchArgument(
        'rviz_config', default_value=os.path.join(share, 'rviz', 'theta_offline.rviz'),
        description='RViz2 config（デバッグは theta_debug.rviz を指定）')
    declare_calibration = DeclareLaunchArgument(
        'calibration', default_value=os.path.join(share, 'config', 'theta_calibration.yaml'),
        description='校正YAML（実機は theta_calibration_real.yaml を指定）')
    declare_min_radius = DeclareLaunchArgument(
        'min_radius', default_value='1.2',
        description='地面点群に含める最小半径[m]（自機の足元を除外）')
    declare_max_radius = DeclareLaunchArgument(
        'max_radius', default_value='4.8',
        description='地面点群に含める最大半径[m]。狭い曲がり角では小さくすると食い合いを軽減')
    declare_grid_range_max = DeclareLaunchArgument(
        'grid_range_max', default_value='7.0',
        description='RTAB-Map Grid/RangeMax。max_radius に合わせて小さくすると安定')
    declare_lidar_topic = DeclareLaunchArgument(
        'lidar_topic', default_value='',
        description='Scan3(2D LiDAR)のトピック。指定するとフリースペースで地面点を制限可能')
    declare_lidar_gate = DeclareLaunchArgument(
        'lidar_gate', default_value='false',
        description='true で /scan3 のフリースペース内の地面点だけを残す（食い合い軽減）')
    declare_lidar_strict = DeclareLaunchArgument(
        'lidar_strict_visibility', default_value='false',
        description='同期LiDARとTFで遮蔽を判定。スキャン不明時は路面を取り込まない')
    declare_lidar_padding = DeclareLaunchArgument('lidar_obstacle_padding_m', default_value='0.0',
        description='厳密な遮蔽判定で障害物の周囲に付ける余白の半径[m]')
    declare_rear_weight = DeclareLaunchArgument('rear_observation_weight', default_value='1.0',
        description='後方の観測重み。前方=1、側方は滑らかに補間（0..1）')
    declare_min_relative_weight = DeclareLaunchArgument('min_relative_observation_weight', default_value='0.0',
        description='各セルの最良観測に対して採用する最低品質比。0=保護無効（0..1）')
    declare_quality_weight_enable = DeclareLaunchArgument(
        'quality_weight_enable', default_value='true',
        description='地面点に観測品質weight（入射角cosのべき乗）を付与する')
    declare_quality_power = DeclareLaunchArgument(
        'quality_power', default_value='2.0',
        description='weight=(h/sqrt(ρ²+h²))^p の指数p。大きいほど遠方を薄くする')
    declare_quality_weight_floor = DeclareLaunchArgument(
        'quality_weight_floor', default_value='0.0',
        description='weight<floor の点を除外（0=全点保持）')
    declare_use_observation_weight = DeclareLaunchArgument(
        'use_observation_weight', default_value='true',
        description='地図蓄積でweightを使う（false=従来の等重み・後勝ちに近い動作）')
    declare_texture_decay = DeclareLaunchArgument(
        'texture_decay', default_value='0.7',
        description='テクスチャ重み付きEMAの減衰率（0-1）')
    declare_class_weight_switch = DeclareLaunchArgument(
        'class_weight_switch', default_value='1.0',
        description='クラス上書きに必要な重み比（新観測 >= 現重み×switch）')
    declare_semantic_min_weight = DeclareLaunchArgument(
        'semantic_min_weight', default_value='0.3',
        description='セマンティック採用に必要な重み合計の下限')
    declare_sam3 = DeclareLaunchArgument(
        'sam3', default_value='false',
        description='Run theta_sam3_perspective_node (needs sam3 docker server)')
    declare_publish_raw = DeclareLaunchArgument(
        'publish_raw', default_value='false',
        description='Republish decoded dual fisheye as raw Image (for RViz debug)')
    declare_publish_debug = DeclareLaunchArgument(
        'publish_debug', default_value='false',
        description='Publish SAM3 view/mask/overlay and semantic-colored cloud for RViz')

    theta_bev = Node(
        package='sirius_navigation', executable='theta_bev_node', name='theta_bev',
        parameters=[{'use_sim_time': use_sim_time, 'use_tf': True,
                     'publish_raw': ParameterValue(publish_raw, value_type=bool),
                     'calibration': calibration}],
        output='screen')

    theta_cloud = Node(
        package='sirius_navigation', executable='theta_ground_cloud_node', name='theta_ground_cloud',
        parameters=[{'use_sim_time': use_sim_time, 'semantic_debug_topic': semantic_debug_topic,
                     'semantic_cloud_topic': '/theta/ground_cloud_semantic',
                     'min_radius': ParameterValue(min_radius, value_type=float),
                     'max_radius': ParameterValue(max_radius, value_type=float),
                     'lidar_topic': lidar_topic,
                     'lidar_gate': ParameterValue(lidar_gate, value_type=bool),
                     'lidar_strict_visibility': ParameterValue(lidar_strict, value_type=bool),
                     'lidar_obstacle_padding_m': ParameterValue(lidar_padding, value_type=float),
                     'quality_weight_enable': ParameterValue(quality_weight_enable, value_type=bool),
                     'quality_power': ParameterValue(quality_power, value_type=float),
                     'rear_observation_weight': ParameterValue(rear_weight, value_type=float),
                     'quality_weight_floor': ParameterValue(quality_weight_floor, value_type=float),
                     'calibration': calibration}],
        output='screen')

    theta_indexed = Node(
        package='sirius_navigation', executable='theta_indexed_map_node', name='theta_indexed_map_node',
        parameters=[{'use_sim_time': use_sim_time,
                     'cloud_topic': '/theta/ground_cloud_semantic',
                     'use_observation_weight': ParameterValue(use_observation_weight, value_type=bool),
                     'texture_decay': ParameterValue(texture_decay, value_type=float),
                     'class_weight_switch': ParameterValue(class_weight_switch, value_type=float),
                     'semantic_min_weight': ParameterValue(semantic_min_weight, value_type=float),
                     'min_relative_observation_weight': ParameterValue(min_relative_weight, value_type=float),
                     'fill_hole_m': ParameterValue(PythonExpression([
                         "0.0 if '", lidar_strict, "' == 'true' else 0.75"]), value_type=float)}],
        output='screen')

    # SAM3セマンティック（任意）。dual-fisheyeを透視投影しSAM3でクラス分類→地面逆投影して
    # /theta/bev_semantic を出す（既存Dockerサーバの単一画像経路）。
    theta_sam3 = Node(
        package='sirius_navigation', executable='theta_sam3_perspective_node', name='theta_sam3_perspective_node',
        parameters=[{'use_sim_time': use_sim_time,
                     'publish_debug': ParameterValue(publish_debug, value_type=bool),
                     'min_radius': ParameterValue(min_radius, value_type=float),
                     'max_radius': ParameterValue(max_radius, value_type=float),
                     'calibration': calibration}],
        condition=IfCondition(sam3),
        output='screen')

    # RTAB-Map（ZED版と同じ設定。scan_cloudだけTHETA地面点群へ差し替え）
    rtabmap_node = Node(
        package='rtabmap_slam', executable='rtabmap', name='rtabmap', output='screen',
        parameters=[{
            'frame_id': 'sirius3/base_footprint',
            'subscribe_scan_cloud': True,
            'subscribe_depth': False,
            'subscribe_rgb': False,
            'approx_sync': True,
            'use_sim_time': use_sim_time,
            'wait_for_transform': 0.2,
            'publish_tf': False,
            'odom_frame_id': 'map',
            'Rtabmap/PublishTf': 'false',
            'Mem/IncrementalMemory': 'true',
            'Mem/InitWMWithAllNodes': 'false',
            'RGBD/ProximityBySpace': 'true',
            'RGBD/AngularUpdate': '0.05',
            'RGBD/LinearUpdate': '0.05',
            'RGBD/OptimizeFromGraphEnd': 'false',
            'Grid/FromDepth': 'false',
            'Reg/Strategy': '0',
            'Reg/Force3DoF': 'true',
            'Mem/MaxSize': '2000',
            'Rtabmap/DetectionRate': '2.0',
            'Grid/VoxelSize': '0.05',
            'Optimizer/Strategy': '1',
            'Grid/RangeMax': ParameterValue(grid_range_max, value_type=str),
            'Grid/RangeMin': '0.8',
            'Grid/NoiseFilteringRadius': '0.1',
            'Grid/NoiseFilteringMinNeighbors': '5',
            'Grid/CellSize': '0.05',
        }],
        remappings=[('scan_cloud', '/theta/ground_cloud'), ('map', '/rtabmap/grid_map')],
        arguments=['--delete_db_on_start'])

    rviz_node = Node(
        package='rviz2', executable='rviz2', name='rviz2_theta_offline',
        arguments=['-d', rviz_config],
        parameters=[{'use_sim_time': use_sim_time}],
        condition=IfCondition(rviz),
        output='screen')

    return LaunchDescription([
        declare_use_sim_time,
        declare_rviz,
        declare_rviz_config,
        declare_calibration,
        declare_min_radius,
        declare_max_radius,
        declare_grid_range_max,
        declare_lidar_topic,
        declare_lidar_gate,
        declare_lidar_strict,
        declare_lidar_padding,
        declare_rear_weight,
        declare_min_relative_weight,
        declare_quality_weight_enable,
        declare_quality_power,
        declare_quality_weight_floor,
        declare_use_observation_weight,
        declare_texture_decay,
        declare_class_weight_switch,
        declare_semantic_min_weight,
        declare_sam3,
        declare_publish_raw,
        declare_publish_debug,
        theta_bev,
        theta_cloud,
        theta_indexed,
        theta_sam3,
        rtabmap_node,
        rviz_node,
    ])
